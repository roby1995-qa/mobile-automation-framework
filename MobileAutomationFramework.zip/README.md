
# Mobile Automation Framework

## Overview
This is a scalable and maintainable framework for mobile automation testing using Appium. The framework is built in Python and structured to include support for reusable components, page objects, and configuration.

## Features
- Modular design with Page Object Model (POM).
- Configurable capabilities via JSON and YAML.
- Integrated with Pytest for test execution.
- Logging utility for better traceability.

## Setup Instructions

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd MobileAutomationFramework
   ```

2. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Start Appium Server**:
   Make sure the Appium server is running at `http://localhost:4723/wd/hub`.

4. **Update Configurations**:
   - Update `config/capabilities.json` with the appropriate device details.
   - Update `config/config.yaml` with the Appium server details and other preferences.

## Running Tests

Execute all tests:
```bash
pytest tests/
```

Generate a report:
```bash
pytest --html=reports/reports.html
```

## Framework Structure

- **config/**: Contains configurations for Appium capabilities and the framework.
- **drivers/**: Handles driver initialization and teardown.
- **pages/**: Implements the Page Object Model.
- **tests/**: Contains test cases.
- **utils/**: Helper utilities like logging.

## Contribution
Feel free to fork and submit pull requests. Contributions are welcome!
