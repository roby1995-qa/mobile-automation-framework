
import json
from appium import webdriver
import yaml

class DriverFactory:
    @staticmethod
    def get_driver():
        with open("./config/capabilities.json") as caps_file:
            capabilities = json.load(caps_file)
        with open("./config/config.yaml") as config_file:
            config = yaml.safe_load(config_file)
        return webdriver.Remote(config["app_url"], capabilities)
