
from .base_page import BasePage
from selenium.webdriver.common.by import By

class LoginPage(BasePage):
    USERNAME_FIELD = (By.ID, "username_field_id")
    PASSWORD_FIELD = (By.ID, "password_field_id")
    LOGIN_BUTTON = (By.ID, "login_button_id")

    def login(self, username, password):
        self.send_keys(self.USERNAME_FIELD, username)
        self.send_keys(self.PASSWORD_FIELD, password)
        self.click(self.LOGIN_BUTTON)
