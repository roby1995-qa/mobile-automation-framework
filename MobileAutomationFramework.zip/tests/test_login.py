
import pytest
from pages.login_page import LoginPage
from drivers.driver_factory import DriverFactory

@pytest.fixture(scope="module")
def driver():
    driver_instance = DriverFactory.get_driver()
    yield driver_instance
    driver_instance.quit()

def test_login(driver):
    login_page = LoginPage(driver)
    login_page.login("test_user", "test_password")
    assert driver.current_activity == "EXPECTED_ACTIVITY"
